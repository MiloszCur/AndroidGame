package com.example.sekwencjaznakwiobrazw;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class GameScreen extends AppCompatActivity {

    Button gotoResult;
    TextView leftProducts;
    int x = 1;
    int mistake = 0;

public static boolean win;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_screen);
        leftProducts = findViewById(R.id.text_leftProducts);
        productsLeftDraw();


    }
    public void selectProduct(View v) {


                GameList gameList = new GameList();

                String imageButtonId = getResourceNameById(v.getId());
                int index = imageButtonId.indexOf("ct");
                String indexProduct = imageButtonId.substring(index+2);
                int productOnlyIndex = Integer.parseInt(indexProduct);

                System.out.println("Kliknięto produkr nr "+productOnlyIndex);


        boolean czyWartoscJestWTabeli = false;

        for (int i = 0; i < gameList.productID.length; i++) {
            if (gameList.productID[i] == productOnlyIndex) {
                czyWartoscJestWTabeli = true;
                break;
            }
        }

        ColorStateList colorStateListGreen = ColorStateList.valueOf(getResources().getColor(R.color.green));
        ColorStateList colorStateListRed = ColorStateList.valueOf(getResources().getColor(R.color.red));

        if(((ImageButton) v).getBackgroundTintList()== colorStateListGreen){

        }else if(((ImageButton) v).getBackgroundTintList()== colorStateListRed){

        } else if (czyWartoscJestWTabeli) {
            ColorStateList colorStateList = ColorStateList.valueOf(getResources().getColor(R.color.green));
            ((ImageButton) v).setBackgroundTintList(colorStateList);

            int number = gameList.size;
            leftProducts.setText("Pozostała liczba produktów: "+(number-x));
            x++;
            if (number-(x-1) == 0)  {
                win= true;
                gameScreen();
            }

        } else {
            ColorStateList colorStateList = ColorStateList.valueOf(getResources().getColor(R.color.red));
            ((ImageButton) v).setBackgroundTintList(colorStateList);

            ImageView heart1 = findViewById(R.id.heart1);
            ImageView heart2 = findViewById(R.id.heart2);
            ImageView heart3 = findViewById(R.id.heart3);
            mistake++;
            if (mistake == 1)   {
                heart1.setVisibility(View.GONE);
            }else if (mistake == 2)   {
                heart2.setVisibility(View.GONE);

            }else if (mistake == 3)   {
                heart3.setVisibility(View.GONE);
                win = false;
                gameScreen();
            }
        }


    }
    private String getResourceNameById(int id)  {
        return getResources().getResourceName(id);
    }


    private void productsLeftDraw(){
        GameList gameList = new GameList();
        leftProducts.setText("Pozostała liczba produktów: "+gameList.size);
    }

    private void gameScreen(){
        Intent intent = new Intent(GameScreen.this,Result.class);
        startActivity(intent);
    }


}