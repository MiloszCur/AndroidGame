package com.example.sekwencjaznakwiobrazw;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.widget.TextView;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class GameList extends AppCompatActivity {


    public final String productString[] = {"mleko","ser","jogurt","masło","jajka","lód","sok pomarańczowy","sok jabłkowy","cola","woda","kawa","herbata","banany","jabłko","pomarańcza","wiśnie","arbuz","ananas","marchew","pomidor","sałata","rzodkiewka","cebula","por","stek","kurczak","ryba","krewetki","kiełbasa","szynka","chleb","chleb tostowy","bagietka","bułka","rogalik","pączek","mydło","szampon","szczoteczka","pasta do zębów","płyn do prania","płyn do szyb","ryż","mąka","olej","cukier","sól","oliwa z oliwek"};
    public static int size = 3;
    public static int level = 1;
    public static int productID[] = new int[10];

    public static int timer = 3000;


    Random random = new Random();
    private void getRandomProducts()    {
        int randomID = 0;

            int i = 0;
            Result result = new Result();

        for (i = 0; i < size; i++)  {
            boolean exist = true;
            while (exist == true)  {
                randomID = random.nextInt(48) + 1;
                exist = false;
                for (int j = i - 1; j >= 0; j--) {
                    if (randomID == productID[j])   {
                        exist = true;
                    }
                }
            }
            productID[i] = randomID;
            System.out.println(productID[i]);
        }
    }
    private void gameScreen(){
        Intent intent = new Intent(GameList.this,GameScreen.class);
        startActivity(intent);
    }

    TextView textViewTimer;
    TextView textViewList;
    TextView textViewLevel;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_list);

        getRandomProducts();
        textViewTimer=findViewById(R.id.text_viewTimer);
        textViewList=findViewById(R.id.text_viewListContent);
        textViewLevel = findViewById(R.id.text_viewScoreList);
        bestLevel();
        drawList();





        new CountDownTimer(timer, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {

                textViewTimer.setText("Time : "+millisUntilFinished/1000+"s");
            }

            @Override
            public void onFinish() {

                textViewTimer.setText("Done");
                gameScreen();
            }
        }.start();

    }

    public static int returnLevel()    {
        return level;
    }


    private void drawList(){

        StringBuilder sb = new StringBuilder();

        for (int i=0;i<size;i++){

            textViewList.append("- "+productString[productID[i] - 1]+"\n");

        }
    }

    private void bestLevel(){
        textViewLevel.setText("Aktualny Poziom : " + returnLevel());
    }

}