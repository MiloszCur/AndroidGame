package com.example.sekwencjaznakwiobrazw;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Result extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);
        lostGameText();


        GameScreen gameScreen = new GameScreen();
        GameList gameList = new GameList();
        if(GameScreen.win == true)  {
            GameList.level++;
            if (GameList.level > 5 && GameList.level <10)    {
                GameList.size = 4;
                GameList.timer = 4000;

            }else if (GameList.level >= 10 && GameList.level <15)    {
                GameList.size = 5;
                GameList.timer = 5000;

            }else if (GameList.level >= 15 && GameList.level <20)    {
                GameList.size = 6;
                GameList.timer = 9000;
            }else if (GameList.level >= 20 && GameList.level <25)    {
                GameList.size = 7;
                GameList.timer = 11000;
            }else if (GameList.level >= 25 && GameList.level <30)    {
                GameList.size = 8;
                GameList.timer = 13000;
            }else if (GameList.level >= 30 && GameList.level <35)    {
                GameList.size = 9;
                GameList.timer = 15000;
            }else if (GameList.level >= 35 && GameList.level <40)    {
                GameList.size = 9;
                GameList.timer = 14000;
            }else if (GameList.level >= 40 && GameList.level <45)    {
                GameList.size = 9;
                GameList.timer = 13000;
            }else if (GameList.level >= 45&& GameList.level <50)    {
                GameList.size = 9;
                GameList.timer = 12000;
            }else if (GameList.level >= 50 && GameList.level <55) {
                GameList.size = 9;
                GameList.timer = 11000;
            }else if (GameList.level >=55 && GameList.level <60) {
                GameList.size = 9;
                GameList.timer = 10000;
            }else if (GameList.level >=65 && GameList.level <70) {
                GameList.size = 9;
                GameList.timer = 9000;
            }else if (GameList.level >=70)  {
                GameList.size = 9;
                GameList.timer = 8000;
            }

        }

        Button gotoMenu = findViewById(R.id.button_resultMenu);
        gotoMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goToMenu();
            }
        });

        Button nextLevel = findViewById(R.id.button_resultLevel);
        nextLevel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                nextLevel();
            }
        });

    }


    private void goToMenu(){
        Intent intent = new Intent(Result.this,MainActivity.class);
        startActivity(intent);
    }
    private void nextLevel(){
        Intent intent = new Intent(Result.this, GameList.class);
        startActivity(intent);
    }


    private void lostGameText(){
        GameScreen gameScreen = new GameScreen();
        TextView textView = findViewById(R.id.textView);
        TextView textViewMistake = findViewById(R.id.textViewMistake);
        Button button= findViewById(R.id.button_resultLevel);

        GameList gameList = new GameList();

        if(gameScreen.win == false){
            textView.setText("Przegrałeś");
            button.setText("Spróbuj Ponownie");
            textViewMistake.setText("Poprawna lista zakupów:");
            for (int i=0;i<gameList.size;i++){

                textViewMistake.append("\n- "+gameList.productString[gameList.productID[i] - 1]);

            }

        }
    }



}